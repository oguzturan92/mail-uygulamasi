

// ALERT SİLME İŞLEMİ
function silOnayla()
{
    return confirm("Bu işlem geri ALINAMAZ. Devam etmek istediğinize emin misiniz?");
}